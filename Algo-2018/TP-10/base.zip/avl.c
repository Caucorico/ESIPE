#include "tree.h"
#include "avl.h"
#include <stddef.h> /* NULL */
#include <stdlib.h>

/* SEARCH */

node *find_avl(node *t, int elt) {
    return NULL;
}

/* UPDATE HEIGHTS */

void update_height(node *t) {
}

/* ROTATIONS */

/*
 *     r            c
 *    / \          / \
 *   c   C   =>   A   r
 *  / \              / \
 * A   B            B   C
 */
node *rotate_right(node *y) {
    return NULL;
}

/*
 *     r            c
 *    / \          / \
 *   A   c   =>   r   C
 *      / \      / \
 *     B   C    A   B
 */
node *rotate_left(node *x) {
    return NULL;
}

node *rotate_left_right(node *y) {
    return NULL;
}

node *rotate_right_left(node *x) {
    return NULL;
}

/* REBALANCE */

int compute_balance(node *t) {
    return 0;
}

node *rebalance(node *t) {
    return NULL;
}

/* INSERTION */

node *insert_avl(node *t, int elt) {
    return NULL;
}

/* CHECK */

int is_avl(node *t)
{
    return 0;
}

/* REMOVAL */

node *extract_min_avl(node *t, node **min) {
    return NULL;
}

node *remove_avl(node *t, int elt) {
    return NULL;
}
