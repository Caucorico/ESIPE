#include <stdio.h>

#include "sudoku.h"

void initialize_empty_board(Board grid){

}

void print_board(Board grid){

}
